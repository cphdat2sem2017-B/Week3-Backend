package exception.demo;

/**
 *
 * @author Henrik Hauge
 */
public class ExceptionDemo
{

    // Follow the instructions.
    // Predict the output before each execution
    // 0) Execute the program
    public static void main(String[] args)
    {
        ExceptionDemo ed = new ExceptionDemo();
        ed.first();
    }

    private void first()
    {
        System.out.println("Hello from first");
        second(1);
        System.out.println("Goodbye from first");
    }

    // Throws unchecked Exception (if the denominator is 0)
    private void second(int denominator)
    {
        System.out.println("Hello from second");
        int c = 7 / denominator;
        System.out.println("Goodbye from second");
    }

    // Code changes (Remember: predict the output before execution):
    // 1) change argument from 1 to 0 
    // 2) catch the exception in "second" - i.e. locally
    // 3) catch the exception in "first"  - i.e. when propagated back 
    // Throws unchecked Exception
    private void third()
    {
        int a[] =
        {
            1, 2, 3
        };
        int b = a[a.length];
    }

	//====== Exercises 
//	4) Call "third" from main and study the error message.
//		
//              Which Exception was thrown?
//              Note:   A list of all method invocations
//                      from main and until the line that 
//                      caused the exception - in reverse order
//		
//      5) Surround the call to "third" with a try/catch block
//         in which you print out a message.
}
